function loadTopics(){
  var file=new android.AssetFile("notes/notes.json");
  return JSON.parse(file.read());
}

function openTopicsList(){
 $("#TOPICS--LIST--CONTAINER").removeClass("HIDE--TOPICS--LIST");
 displayData("", { on_close:"closeTopicsList", osclose: true, oszindex: 15, dummy: true, data_id: "dummy-topics-list" });
}


function closeTopicsList(){
  closeDisplayData("dummy-topics-list");
 $("#TOPICS--LIST--CONTAINER").addClass("HIDE--TOPICS--LIST");
// $(".SUB--TOPICS--CONTAINER").css("display","none");
  $(".SUB--TOPICS--BTN").css("display","block");
}

var TOPICS=loadTopics();
var TOTAL_TOPICS= TOPICS.length;


function subTopics( sub_topics, page ){

   var list='<div id="SUB--TOPICS--CONTAINER--' + page + '" class="SUB--TOPICS--CONTAINER">';
    
 $.each( sub_topics, function(key, sub_topic_){
      
      list+='<div class="container SUB--TOPICS--BTN" id="SUB--TOPIC--' + key + '" data-sub-topic="' + key + '" data-page="' + page + '" onclick="loadPage(event, ' + page+ ');">';
      list+='<div class="row">';
      list+='<div class="col w-60"><img class="TITLE--ICON" src="file:///assets/images/button-icons/forward-grey.png"></div>';
      list+='<div class="col p-0"><div class="TITLE">' + sub_topic_ + '</div></div>';
      list+='</div>';
      list+='</div>';
      
  });
     list+='</div>';
 
 return list; 
}


function listTopics(){
  var list_='';
  
  $.each( TOPICS, function(i,v){
      var title=    v.title;
      var kwords=   v.keywords;
      var sub_topics= v.sub_topics;
      var page=i+1;
  var curr=+localStorage.getItem("current_page")||1;
      list_+='<div class="t">';
    
      list_+='<div class="container-fluid TOPIC--LIST--BTN' + ( curr==page?" TOPIC--SELECTED":"") + '" id="TOPIC-' + page + '" data-sub-topic="" onclick="loadPage(event,' + page + ');">';
      list_+='<div class="row">';
      list_+='<div class="col w-60"><img class="TITLE--ICON" src="file:///assets/images/button-icons/forward-grey.png"></div>';
      list_+='<div class="col"><div class="TITLE">' + title + '</div><div class="d-none">' + kwords + '</div></div>';
     
   if(sub_topics.length){
      list_+='<div class="col w-60 text-center SUB--TOPICS--TOGGLE--BTN" data-page="' + page + '"><img class="stt-btn" src="file:///assets/images/button-icons/sub-menu.png" style="width: 16px;"></div>';
     }
      list_+='</div>';
      list_+='</div>';
    
   if( sub_topics.length){
     list_+=subTopics( sub_topics, page); 
   }
    list_+='</div>';

   });
  
  $("#TOPICS--LIST").html( list_ );
  $("#TOPICS--LIST--CONTAINER").scrollTop( +localStorage.getItem("topics-scroll-pos")||0 );  
}
  
  
  
function loadPage(event,page_, nav){
  var this_=$(event.currentTarget);
  var target_=$(event.target);
  
var page=page_||localStorage.getItem("current_page")||1;
    page=+page;
  
 if( nav ===-1) {
   page=page-1;
 }
  else if ( nav===1){
   page=page+1;
  }
  
  if( page<1 ){
    return toast("No more");
  }else if( page > TOTAL_TOPICS){
    return toast("No more");
  }
  
  $(".TOPIC--LIST--BTN").removeClass("TOPIC--SELECTED");
  $("#TOPIC-" + page).addClass("TOPIC--SELECTED");
 
  
if( event && ( target_.hasClass("SUB--TOPICS--TOGGLE--BTN") || target_.hasClass("stt-btn") ) ){
 var sub_topic_cont=$("#SUB--TOPICS--CONTAINER--" + page);
 
 if( sub_topic_cont.is(":visible") ){
    sub_topic_cont.slideUp();
 }else{
    sub_topic_cont.slideDown();
 }
  
  return;
}
 
var sub_topic=this_.data("sub-topic");

$(".SUB--TOPICS--BTN").removeClass("SUB--TOPIC--SELECTED");
 
if( sub_topic ){
  this_.addClass("SUB--TOPIC--SELECTED");
}
  
  
var result= TOPICS[page-1];
var path_=result.path + "/" + page + ".html";
  
var path= "file:///assets/notes/notes/" + path_; 

 var title= result.title;
 $("#toolbar-title").text( title);

  var page_folder=path_.split("/")[0];
 
  $.ajax({
     url: path,
    type: "GET",
    dataType:"text",
  }).done(function(note){
    
  var data=bbCode( note  );
   
 $("#NOTE--TEXTS").html( data.replace(/\n/g,"<br>") );
       
  if( sub_topic){
     $(".sub-topic").css("display","none");
     $(".sub-topic-" + sub_topic).css("display","block");
  }
   else{
     localStorage.setItem("current_page", page);
   }
    
  $("#CURRENT--PAGE").val(page);

  var dir=new android.File(EXTERNAL_DIR, "NOTES-METAS/" + page);
  var file=new android.File(dir, "scroll-pos.txt");

 if( file.isFile() ){
  var pos=+file.read()||0
  $("#NOTE--CONTAINER").animate({scrollTop: pos});
 }
  var tsearch=$.trim( $("#TOPICS--SEARCH--BOX").val())
  var text=$.trim($("#SEARCH--BOX").val())||tsearch;
  if( text.length ) {
  var elem=$("#NOTE--TEXTS");
    elem.unmark().mark(text);
  var found=elem.find("mark").length;
    $("#SEARCH--FOUND").text(found||"")
   elem.scrollTo("mark:first", 3000);
 }
  }).fail(function(e,txt,xhr){
    toast("Not found. " + xhr)
  });
  
if(page_ ) closeTopicsList();
  
 settings_();
  
}


function nextPrev(nav){
 $("#TOPICS--SEARCH--BOX").val("");
 loadPage({},0,nav);
 }

function enlargePhoto(t, double){
 var this_=$(t);
  
  if( double){
  var size=+this_.attr("data-size")+50;
  if( size>250){
    return $(".ENLARGED--PHOTO").attr("data-size", "100").css({"width": "","max-width":"100vw","max-height":"100vh"});   
  }
  return $(".ENLARGED--PHOTO").attr("data-size", size).css({"width": size +"%","max-width":1200,"max-height":1200});   
  }
 
 var src=this_.attr("src");
 $("#ENLARGED--PHOTO--CHILD--CONT").html('<img onclick="enlargePhoto(this,1);" data-size="100" src="' + src + '" class="ENLARGED--PHOTO">');
 openCustomPage("ENLARGED--PHOTO--CONT");
}


function openSearchBox(){
  $(".search-box-container").fadeIn();  
}

function closeSearchBox(){
  $(".search-box-container").css("display","none");  
  $("#NOTE--TEXTS").unmark();
  $("#SEARCH--BOX").val("");
  $("#SEARCH--FOUND").text("")
     
}


function isMobile(){
  return $("#IS--MOBILE").is(":visible");
}


function settings_(){
  var fs=+localStorage.getItem("text-font-size")||14;
  var fw=localStorage.getItem("text-font-weight")||"Normal";
  var tc=localStorage.getItem("text-color")||"black";
  var bc=localStorage.getItem("background-color")||"white";
  var lg=localStorage.getItem("text-line-gap")||"1.6";

 $("#NOTE--CONTAINER").css({"font-size": fs,"font-weight":fw, color:tc, "line-height":lg + "em"});
 $("body,#TOPICS--LIST--CONTAINER").css({background:bc});
 $("#TOPICS--LIST--CONTAINER").css({color:tc});
  }
  


var scrollTimer;
var searchTimer;

$(function(){
loadTemplate();

 $("#NOTE--CONTAINER").on("scroll", function() {
 var nextPrevBtn=$("#NOTE--NAV--CONTAINER button")
   var page=$("#CURRENT--PAGE").val()||1;
  var dir=new android.File(EXTERNAL_DIR, "NOTES-METAS/" + page);
  var pos=$("#NOTE--CONTAINER").scrollTop();
   clearTimeout( scrollTimer);
     scrollTimer=setTimeout(function(){
     if(!dir.isDirectory() && !dir.mkdirs()){
       return; }
    var file=new android.File(dir, "scroll-pos.txt");
  file.write( pos);
 
 nextPrevBtn.animate({opacity:"0.5"},2000);
       
       
 }, 400);
   
  nextPrevBtn.css({opacity:1});
   
 });
  
  
 
 $("#TOPICS--LIST--CONTAINER").on("scroll", function(){
   var pos=$(this).scrollTop();
  localStorage.setItem("topics-scroll-pos", pos);
 });
  
  
 $("body").on("input","#SEARCH--BOX", function(){   
   clearTimeout(searchTimer);
   var sf= $("#SEARCH--FOUND");
   var sl=$("#SEARCH--LOADER");
   
    sf.hide(); sl.show();
   searchTimer=setTimeout(function(){
   var text=$.trim( $("#SEARCH--BOX").val())
   $("#NOTE--TEXTS").unmark().mark(text);
   var found=$("#NOTE--TEXTS mark").length;
    sl.hide();
    sf.text(found||"");
    sf.show();
   },900);
 });
  
  
 $("body").on("input","#TOPICS--SEARCH--BOX", function() {
  // Retrieve the input field text and reset the count to zero
      var filter = $(this).val(),
        count = 0;
   // Loop through the comment list
      $("#TOPICS--LIST .TOPIC--LIST--BTN, .SUB--TOPICS--CONTAINER, .SUB--TOPICS--BTN").each(function() {
      // If the list item does not contain the text phrase fade it out
        if ($(this).text().search(new RegExp(filter, "i")) < 0) {
          $(this).hide();  // MY CHANGE
          // Show the list item if the phrase matches and increase the count by 1
        } else {
          $(this).show(); // MY CHANGE
          count++;
        }
      });
 });
  
  
});



function doOnOrientationChange() {
   function ori(){
     switch(window.orientation) {
      case 90:
         return 2;
        break;
      case -90:
        return 2;
        break;
      case 0:
        return 1;
        break;
      case 180:
        return 1
        break;
      default:
        break;
    }
   }
  
//var val_=ori();
  closeTopicsList();
  
}

window.addEventListener('orientationchange', doOnOrientationChange);

// Initial execution if needed
doOnOrientationChange();

window.addEventListener('onOrientationChanged',function(newConfig){

// Checks the orientation of the screen
   alert (newConfig.orientation)
});


function onBackPressed() {
  var total_op=customPageOpenedIds.length;

 var adCount=1; //localStorage.getItem('app_ad_count'); 
 
  if($(".so-options-container").is(":visible")){
 return $(".so-options-container").css("display","none");
  } 
 else  
 if( $('.display--data').length ){
  var elem=$('.display--data').last();
    var on_close=elem.data("on-close");
   if(!elem.hasClass('no-cancel') ){
   closeDisplayData( elem.data('id'), on_close );
 }
  return;
}
 else if( total_op){
     var last=customPageOpenedIds[total_op-1];
    closeCustomPage(null,last);
    return;
  }   
 else if( $(".search-box-container:visible").length){
    closeSearchBox();
    return;
  }
  
  
if( adCount){
  localStorage.removeItem('app_ad_count'); 
 if(confirm("Do you really want to quit?")) {  
   sessionStorage.clear();
   android.activity.finish();
  }
 }
  else{
  showExitAd();
  localStorage.setItem('app_ad_count','1');
 }
 
}

function showExitAd(){
  
}
