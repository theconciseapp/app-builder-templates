var APP_VERSION='1.0';
var APP_LABEL__='Pride and Prejudice';
var API_LEVEL = android.system.getApiLevel(); //Don't change
var act__ = new android.JavaObject("activity"); //Don't change
var PACKAGE_NAME = act__.getPackageName(); //Don't change

 var DEFAULT_TEMPLATE="Alpha Note 2022"; //Don't change
     
 var BLOG_URL="https://t.me/osbapps";
 var autoBackup=true;

 var ASSETS_DOMAIN="file:///assets"; //Don't change

 var AUTHOR_NAME="Jane Austen";
 
 var telegramLink="https://t.me/oluwaseyi_bankole";
 var whatsappLink="https://wa.me/23412345678";
 