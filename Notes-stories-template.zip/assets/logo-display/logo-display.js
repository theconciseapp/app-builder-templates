$( function(){
  $(".app-label").text(APP_LABEL__);
 // $('#header').show();
 //  animateCSS('#header','slideInLeft slow');
  $("#author-name,#author-name-2").text( AUTHOR_NAME );
  if(!localStorage.getItem("install_status")){
   
setTimeout(function(){
  $("#author-name").fadeOut();
 $("#splash-image").fadeOut(function(){
 $("#splash-image-2-cont").css("display","block");
   animateCSS("#splash-image-2-cont","bounceInDown slow",function(){ 
   $("#powered,#author-name2,#app-label").fadeIn();
   });
 });
   
},3000);
  $("#load").show();

  setTimeout(function(){
   android.activity.hideView("logo_display");
   android.control.execute("unlockDrawer()");   
 },9000); 
 
    
}
  
else{
  
  setTimeout(function(){
    startOwnActivity("installActivity");
  android.activity.finish();
  },4000);
 
}
  
});
  